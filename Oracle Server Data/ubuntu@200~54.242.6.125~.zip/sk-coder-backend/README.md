# SK Coder Backend

Stateless execution server for SK Coder IDE. Handles real terminal sessions and code execution.

## Requirements on the AWS server

- Node.js 20+
- Python 3.11+
- GCC/G++ 12+
- OpenJDK 17+
- Go 1.21+ (optional)
- Ruby 3+ (optional)
- PHP 8+ (optional)
- Docker (recommended)

## Quick Start (Docker — recommended)

```bash
git clone <your-repo>
cd sk-coder-backend
docker-compose up -d
```

The server starts on port 4000.

## Manual Setup

```bash
npm install
npm run build
PORT=4000 npm start
```

## AWS EC2 Deployment

1. Launch EC2 (Ubuntu 22.04 LTS, t3.medium or larger)
2. Open port 4000 in security group (or 443 with nginx reverse proxy)
3. SSH into instance:
   ```bash
   sudo apt update && sudo apt install -y nodejs npm docker.io docker-compose
   git clone <your-repo> sk-coder-backend
   cd sk-coder-backend
   sudo docker-compose up -d
   ```

## NGINX + SSL (recommended for production)

```nginx
server {
    listen 443 ssl;
    server_name your-backend-domain.com;
    
    ssl_certificate /etc/letsencrypt/live/your-domain/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/your-domain/privkey.pem;
    
    location / {
        proxy_pass http://localhost:4000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
    }
}
```

## API Endpoints

| Method | Path | Description |
|--------|------|-------------|
| GET | /health | Server health check |
| POST | /api/execute | Execute code (Python, C, C++, Java, etc.) |
| WS | /api/terminal | Real bash terminal WebSocket |

## Connect from SK Coder Web App

In the web app, go to **Settings → Backend URL** and enter:
```
wss://your-backend-domain.com
```

Or for HTTP (non-SSL):
```
ws://your-ec2-ip:4000
```

## Supported Languages

Python 3, JavaScript (Node.js), TypeScript, C, C++, Java, Go, Rust, PHP, Ruby, Bash, Kotlin
