import { spawn } from "child_process";
import { writeFileSync, mkdirSync, rmSync } from "fs";
import { join } from "path";
import os from "os";
import { randomUUID } from "crypto";

export interface ExecResult {
  stdout: string;
  stderr: string;
  exitCode: number;
  executionTime: number;
  language: string;
}

export const SUPPORTED_LANGUAGES = [
  { id: "python",     name: "Python 3",      extensions: [".py"],             description: "General purpose scripting" },
  { id: "javascript", name: "JavaScript",    extensions: [".js", ".mjs"],     description: "Node.js 18+" },
  { id: "typescript", name: "TypeScript",    extensions: [".ts"],             description: "via ts-node" },
  { id: "java",       name: "Java",          extensions: [".java"],           description: "JDK 17+" },
  { id: "c",          name: "C",             extensions: [".c"],              description: "gcc, C11 standard" },
  { id: "cpp",        name: "C++",           extensions: [".cpp", ".cc"],     description: "g++, C++17 standard" },
  { id: "go",         name: "Go",            extensions: [".go"],             description: "Go 1.21+" },
  { id: "rust",       name: "Rust",          extensions: [".rs"],             description: "rustc stable" },
  { id: "ruby",       name: "Ruby",          extensions: [".rb"],             description: "Ruby 3+" },
  { id: "php",        name: "PHP",           extensions: [".php"],            description: "PHP 8+" },
  { id: "bash",       name: "Bash",          extensions: [".sh", ".bash"],    description: "Bash shell" },
  { id: "kotlin",     name: "Kotlin",        extensions: [".kt"],             description: "kotlinc + JVM" },
  { id: "csharp",     name: "C#",            extensions: [".cs"],             description: ".NET via dotnet-script" },
  { id: "lua",        name: "Lua",           extensions: [".lua"],            description: "Lua 5.4" },
  { id: "swift",      name: "Swift",         extensions: [".swift"],          description: "Swift 5+" },
  { id: "perl",       name: "Perl",          extensions: [".pl", ".pm"],      description: "Perl 5+" },
  { id: "r",          name: "R",             extensions: [".r", ".R"],        description: "R statistical computing" },
  { id: "dart",       name: "Dart",          extensions: [".dart"],           description: "Dart SDK" },
  { id: "scala",      name: "Scala",         extensions: [".scala"],          description: "Scala 3 via scala-cli" },
  { id: "haskell",    name: "Haskell",       extensions: [".hs"],             description: "GHCi interpreter" },
  { id: "elixir",     name: "Elixir",        extensions: [".ex", ".exs"],     description: "Elixir via elixir CLI" },
  { id: "clojure",    name: "Clojure",       extensions: [".clj"],            description: "Clojure via clojure CLI" },
  { id: "fsharp",     name: "F#",            extensions: [".fs", ".fsx"],     description: ".NET F# script" },
  { id: "powershell", name: "PowerShell",    extensions: [".ps1"],            description: "pwsh on Linux" },
];

async function runProc(
  cmd: string,
  args: string[],
  cwd: string,
  timeout = 30000,
  stdin?: string
): Promise<{ stdout: string; stderr: string; exitCode: number }> {
  return new Promise((resolve) => {
    const proc = spawn(cmd, args, {
      cwd,
      env: {
        ...process.env,
        HOME: os.homedir(),
        GOPATH: join(os.homedir(), "go"),
        PATH: [
          "/usr/local/bin",
          "/usr/bin",
          "/bin",
          "/usr/local/go/bin",
          join(os.homedir(), ".cargo", "bin"),
          join(os.homedir(), ".local", "bin"),
          process.env["PATH"] || "",
        ].join(":"),
      },
    });

    let stdout = "";
    let stderr = "";
    let done = false;

    const timer = setTimeout(() => {
      if (!done) {
        done = true;
        proc.kill("SIGKILL");
        resolve({ stdout, stderr: stderr + "\n⏱ Timeout: execution exceeded 30s limit", exitCode: -1 });
      }
    }, timeout);

    proc.stdout.on("data", (d: Buffer) => { stdout += d.toString(); });
    proc.stderr.on("data", (d: Buffer) => { stderr += d.toString(); });

    if (stdin) {
      proc.stdin.write(stdin);
      proc.stdin.end();
    }

    proc.on("close", (code) => {
      if (!done) {
        done = true;
        clearTimeout(timer);
        resolve({ stdout, stderr, exitCode: code ?? 0 });
      }
    });

    proc.on("error", (e) => {
      if (!done) {
        done = true;
        clearTimeout(timer);
        resolve({ stdout, stderr: stderr + "\n" + e.message, exitCode: -1 });
      }
    });
  });
}

export async function executeCode(
  code: string,
  language: string,
  filename?: string,
  stdin?: string
): Promise<ExecResult> {
  const tmpDir = join(os.tmpdir(), `sk-exec-${randomUUID()}`);
  mkdirSync(tmpDir, { recursive: true });
  const start = Date.now();
  const lang = language.toLowerCase().trim();

  let result: { stdout: string; stderr: string; exitCode: number };

  try {
    if (lang === "python" || lang === "python3" || lang === "py") {
      const f = filename || "main.py";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("python3", [f], tmpDir, 30000, stdin);

    } else if (lang === "javascript" || lang === "node" || lang === "nodejs" || lang === "js") {
      const f = filename || "main.js";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("node", [f], tmpDir, 30000, stdin);

    } else if (lang === "typescript" || lang === "ts") {
      const f = filename || "main.ts";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("npx", ["--yes", "ts-node", "--transpile-only", f], tmpDir, 60000, stdin);

    } else if (lang === "c") {
      const f = filename || "main.c";
      writeFileSync(join(tmpDir, f), code);
      const compile = await runProc("gcc", [f, "-o", "sk_out", "-Wall", "-Wextra", "-std=c11", "-lm"], tmpDir);
      result = compile.exitCode !== 0 ? compile : await runProc("./sk_out", [], tmpDir, 30000, stdin);

    } else if (lang === "cpp" || lang === "c++" || lang === "cc") {
      const f = filename || "main.cpp";
      writeFileSync(join(tmpDir, f), code);
      const compile = await runProc("g++", [f, "-o", "sk_out", "-Wall", "-Wextra", "-std=c++17", "-lm"], tmpDir);
      result = compile.exitCode !== 0 ? compile : await runProc("./sk_out", [], tmpDir, 30000, stdin);

    } else if (lang === "java") {
      const cls = (code.match(/public\s+class\s+(\w+)/) || ["", "Main"])[1];
      const f = `${cls}.java`;
      writeFileSync(join(tmpDir, f), code);
      const compile = await runProc("javac", ["-encoding", "UTF-8", f], tmpDir);
      result = compile.exitCode !== 0 ? compile : await runProc("java", ["-cp", ".", cls], tmpDir, 30000, stdin);

    } else if (lang === "go" || lang === "golang") {
      const f = filename || "main.go";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("go", ["run", f], tmpDir, 60000, stdin);

    } else if (lang === "rust" || lang === "rs") {
      const f = filename || "main.rs";
      writeFileSync(join(tmpDir, f), code);
      const compile = await runProc("rustc", [f, "-o", "sk_out", "--edition", "2021"], tmpDir, 60000);
      result = compile.exitCode !== 0 ? compile : await runProc("./sk_out", [], tmpDir, 30000, stdin);

    } else if (lang === "ruby" || lang === "rb") {
      const f = filename || "main.rb";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("ruby", [f], tmpDir, 30000, stdin);

    } else if (lang === "php") {
      const f = filename || "main.php";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("php", [f], tmpDir, 30000, stdin);

    } else if (lang === "bash" || lang === "sh" || lang === "shell") {
      const f = filename || "main.sh";
      writeFileSync(join(tmpDir, f), code, { mode: 0o755 });
      result = await runProc("bash", [f], tmpDir, 30000, stdin);

    } else if (lang === "kotlin" || lang === "kt") {
      const f = filename || "main.kt";
      writeFileSync(join(tmpDir, f), code);
      const compile = await runProc("kotlinc", [f, "-include-runtime", "-d", "sk_out.jar"], tmpDir, 90000);
      result = compile.exitCode !== 0 ? compile : await runProc("java", ["-jar", "sk_out.jar"], tmpDir, 30000, stdin);

    } else if (lang === "csharp" || lang === "cs" || lang === "c#") {
      const f = filename || "main.csx";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("dotnet-script", [f], tmpDir, 60000, stdin);

    } else if (lang === "lua") {
      const f = filename || "main.lua";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("lua5.4", [f], tmpDir, 30000, stdin)
        .catch(() => runProc("lua", [f], tmpDir, 30000, stdin));

    } else if (lang === "swift") {
      const f = filename || "main.swift";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("swift", [f], tmpDir, 60000, stdin);

    } else if (lang === "perl" || lang === "pl") {
      const f = filename || "main.pl";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("perl", [f], tmpDir, 30000, stdin);

    } else if (lang === "r") {
      const f = filename || "main.r";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("Rscript", [f], tmpDir, 30000, stdin);

    } else if (lang === "dart") {
      const f = filename || "main.dart";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("dart", ["run", f], tmpDir, 60000, stdin);

    } else if (lang === "scala") {
      const f = filename || "main.scala";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("scala-cli", ["run", f], tmpDir, 90000, stdin)
        .catch(() => runProc("scala", [f], tmpDir, 90000, stdin));

    } else if (lang === "haskell" || lang === "hs") {
      const f = filename || "main.hs";
      writeFileSync(join(tmpDir, f), code);
      const compile = await runProc("ghc", ["-o", "sk_out", f, "-outputdir", tmpDir], tmpDir, 60000);
      result = compile.exitCode !== 0 ? compile : await runProc("./sk_out", [], tmpDir, 30000, stdin);

    } else if (lang === "elixir" || lang === "ex" || lang === "exs") {
      const f = filename || "main.exs";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("elixir", [f], tmpDir, 30000, stdin);

    } else if (lang === "clojure" || lang === "clj") {
      const f = filename || "main.clj";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("clojure", ["-M", f], tmpDir, 60000, stdin);

    } else if (lang === "fsharp" || lang === "fs" || lang === "fsx") {
      const f = filename || "main.fsx";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("dotnet", ["fsi", f], tmpDir, 60000, stdin);

    } else if (lang === "powershell" || lang === "ps1") {
      const f = filename || "main.ps1";
      writeFileSync(join(tmpDir, f), code);
      result = await runProc("pwsh", ["-File", f], tmpDir, 30000, stdin)
        .catch(() => runProc("powershell", ["-File", f], tmpDir, 30000, stdin));

    } else {
      result = {
        stdout: "",
        stderr: `Language '${language}' is not configured on this server.\nSupported: ${SUPPORTED_LANGUAGES.map(l => l.id).join(", ")}`,
        exitCode: 1,
      };
    }
  } finally {
    try { rmSync(tmpDir, { recursive: true, force: true }); } catch {}
  }

  return { ...result!, executionTime: Date.now() - start, language: lang };
}
