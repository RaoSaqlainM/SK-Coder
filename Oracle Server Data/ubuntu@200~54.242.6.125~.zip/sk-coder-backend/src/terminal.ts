import { WebSocket } from "ws";
import { IncomingMessage } from "http";
import { spawn, ChildProcess } from "child_process";
import os from "os";
import path from "path";

const SHELL = os.platform() === "win32" ? "cmd.exe" : "/bin/bash";
const MAX_OUTPUT = parseInt(process.env["MAX_OUTPUT_SIZE"] || "1048576", 10);

interface Session {
  cwd: string;
  proc: ChildProcess | null;
  outputSize: number;
}

function send(ws: WebSocket, type: string, data: string) {
  if (ws.readyState === WebSocket.OPEN) {
    ws.send(JSON.stringify({ type, data }));
  }
}

function prompt(ws: WebSocket, cwd: string) {
  const short = cwd.replace(os.homedir(), "~");
  send(ws, "output", `\r\n\x1b[32m${short}\x1b[0m \x1b[34m$\x1b[0m `);
}

export function handleTerminalSocket(ws: WebSocket, _req: IncomingMessage) {
  const session: Session = {
    cwd: os.homedir(),
    proc: null,
    outputSize: 0,
  };

  send(ws, "output", `\x1b[1;34mSK Coder Terminal\x1b[0m — bash ${SHELL}\r\n`);
  send(ws, "output", `Type \x1b[33mhelp\x1b[0m for commands. Working dir: ${session.cwd}\r\n`);
  prompt(ws, session.cwd);

  let lineBuffer = "";

  ws.on("message", (raw) => {
    let msg: { type: string; data?: string; path?: string; command?: string };
    try { msg = JSON.parse(raw.toString()); } catch { return; }

    if (msg.type === "cd_path") {
      const target = msg.path || msg.data || "";
      const resolved = path.isAbsolute(target) ? target : path.join(session.cwd, target);
      try {
        process.chdir(resolved);
        session.cwd = process.cwd();
        send(ws, "cwd", session.cwd);
        send(ws, "output", `\r\n\x1b[33mcd ${session.cwd}\x1b[0m`);
        prompt(ws, session.cwd);
      } catch (e: any) {
        send(ws, "error", `\r\ncd: ${e.message}`);
        prompt(ws, session.cwd);
      }
      return;
    }

    if (msg.type === "run_file") {
      const filePath = msg.path || "";
      const dir = path.dirname(filePath);
      const name = path.basename(filePath);
      const ext = path.extname(name).slice(1).toLowerCase();
      const cmds: Record<string, string> = {
        py: `python3 "${name}"`,
        js: `node "${name}"`,
        ts: `ts-node "${name}"`,
        sh: `bash "${name}"`,
        rb: `ruby "${name}"`,
        php: `php "${name}"`,
        go: `go run "${name}"`,
        c: `gcc "${name}" -o _out -Wall && ./_out && rm -f _out`,
        cpp: `g++ "${name}" -o _out -std=c++17 -Wall && ./_out && rm -f _out`,
        java: `javac "${name}" && java "${name.replace(/\.java$/, "")}"`,
        rs: `rustc "${name}" -o _out && ./_out && rm -f _out`,
      };
      const command = cmds[ext];
      if (command) {
        try { process.chdir(dir); session.cwd = dir; } catch {}
        send(ws, "output", `\r\n\x1b[33m$ ${command}\x1b[0m\r\n`);
        runCommand(ws, session, command);
      } else {
        send(ws, "error", `\r\nNo runner for .${ext} files`);
        prompt(ws, session.cwd);
      }
      return;
    }

    if (msg.type === "input") {
      const ch = msg.data || "";
      send(ws, "echo", ch);

      if (ch === "\x03") {
        if (session.proc) {
          session.proc.kill("SIGINT");
          session.proc = null;
          send(ws, "output", "^C\r\n");
          prompt(ws, session.cwd);
          lineBuffer = "";
        }
        return;
      }

      if (ch === "\x7f" || ch === "\b") {
        if (lineBuffer.length > 0) {
          lineBuffer = lineBuffer.slice(0, -1);
          send(ws, "output", "\b \b");
        }
        return;
      }

      if (ch === "\r" || ch === "\n") {
        const line = lineBuffer.trim();
        lineBuffer = "";
        send(ws, "output", "\r\n");
        if (!line) { prompt(ws, session.cwd); return; }

        if (line === "clear" || line === "cls") {
          send(ws, "output", "\x1b[2J\x1b[H");
          prompt(ws, session.cwd);
          return;
        }

        if (line.startsWith("cd ") || line === "cd") {
          const target = line.slice(3).trim() || os.homedir();
          const resolved = target === "~" ? os.homedir() :
            path.isAbsolute(target) ? target : path.join(session.cwd, target);
          try {
            process.chdir(resolved);
            session.cwd = process.cwd();
            send(ws, "cwd", session.cwd);
            prompt(ws, session.cwd);
          } catch (e: any) {
            send(ws, "error", `cd: no such file or directory: ${target}\r\n`);
            prompt(ws, session.cwd);
          }
          return;
        }

        runCommand(ws, session, line);
      } else {
        lineBuffer += ch;
      }
    }
  });

  ws.on("close", () => {
    if (session.proc) { try { session.proc.kill(); } catch {} }
  });

  ws.on("error", () => {
    if (session.proc) { try { session.proc.kill(); } catch {} }
  });
}

function runCommand(ws: WebSocket, session: Session, command: string) {
  if (session.proc) { try { session.proc.kill(); } catch {} }
  session.outputSize = 0;

  const maxTime = parseInt(process.env["MAX_EXECUTION_TIME"] || "30000", 10);

  const proc = spawn(SHELL, ["-c", command], {
    cwd: session.cwd,
    env: {
      ...process.env,
      TERM: "xterm-256color",
      COLUMNS: "220",
      LINES: "40",
      HOME: os.homedir(),
      PATH: process.env["PATH"] || "/usr/local/bin:/usr/bin:/bin",
    },
  });

  session.proc = proc;

  const timer = setTimeout(() => {
    if (session.proc === proc) {
      proc.kill("SIGKILL");
      send(ws, "error", "\r\n\x1b[31mProcess killed: execution timeout\x1b[0m\r\n");
      prompt(ws, session.cwd);
    }
  }, maxTime);

  const writeOutput = (data: Buffer, isErr = false) => {
    session.outputSize += data.length;
    if (session.outputSize > MAX_OUTPUT) {
      proc.kill("SIGKILL");
      send(ws, "error", "\r\n\x1b[31mOutput size limit reached\x1b[0m\r\n");
      return;
    }
    const text = data.toString().replace(/\n/g, "\r\n");
    send(ws, isErr ? "error" : "output", text);
  };

  proc.stdout.on("data", (d: Buffer) => writeOutput(d, false));
  proc.stderr.on("data", (d: Buffer) => writeOutput(d, true));

  proc.on("close", (code) => {
    clearTimeout(timer);
    if (session.proc === proc) {
      session.proc = null;
      if (code !== 0 && code !== null) {
        send(ws, "output", `\r\n\x1b[2m[exit code: ${code}]\x1b[0m`);
      }
      prompt(ws, session.cwd);
    }
  });

  proc.on("error", (e) => {
    clearTimeout(timer);
    if (session.proc === proc) {
      session.proc = null;
      send(ws, "error", `\r\nCommand error: ${e.message}\r\n`);
      prompt(ws, session.cwd);
    }
  });
}
