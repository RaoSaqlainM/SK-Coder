import express from "express";
import { createServer } from "http";
import { WebSocketServer } from "ws";
import cors from "cors";
import helmet from "helmet";
import multer from "multer";
import path from "path";
import os from "os";
import { handleTerminalSocket } from "./terminal";
import { executeCode, SUPPORTED_LANGUAGES } from "./executor";

const app = express();
const server = createServer(app);
const wss = new WebSocketServer({ server, path: "/api/terminal" });

const allowedOrigins = (process.env["ALLOWED_ORIGINS"] || "*").split(",");

app.use(helmet({ contentSecurityPolicy: false, crossOriginEmbedderPolicy: false }));
app.use(cors({
  origin: allowedOrigins.includes("*") ? "*" : allowedOrigins,
  methods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
  allowedHeaders: ["Content-Type", "Authorization"],
}));
app.use(express.json({ limit: "100mb" }));
app.use(express.urlencoded({ extended: true, limit: "100mb" }));

const upload = multer({
  dest: path.join(os.tmpdir(), "sk-coder-uploads"),
  limits: { fileSize: 500 * 1024 * 1024 },
});

wss.on("connection", (ws, req) => {
  handleTerminalSocket(ws, req);
});

app.get("/health", (_req, res) => {
  res.json({
    status: "ok",
    name: "SK Coder Backend",
    version: "3.0.0",
    platform: os.platform(),
    arch: os.arch(),
    node: process.version,
    uptime: Math.round(process.uptime()),
    memory: {
      used: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
      total: Math.round(os.totalmem() / 1024 / 1024),
      free: Math.round(os.freemem() / 1024 / 1024),
    },
    cpus: os.cpus().length,
    hostname: os.hostname(),
  });
});

app.get("/api/languages", (_req, res) => {
  res.json({
    languages: SUPPORTED_LANGUAGES,
    total: SUPPORTED_LANGUAGES.length,
  });
});

app.post("/api/execute", async (req, res) => {
  const { code, language, filename, stdin } = req.body as {
    code: string;
    language: string;
    filename?: string;
    stdin?: string;
  };
  if (!code || !language) {
    res.status(400).json({ error: "code and language are required" });
    return;
  }
  try {
    const result = await executeCode(code, language, filename, stdin);
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message || "Execution failed", stdout: "", stderr: err.message, exitCode: -1 });
  }
});

app.post("/api/execute/batch", async (req, res) => {
  const { jobs } = req.body as {
    jobs: Array<{ code: string; language: string; filename?: string; stdin?: string }>;
  };
  if (!Array.isArray(jobs) || jobs.length === 0) {
    res.status(400).json({ error: "jobs array required" });
    return;
  }
  if (jobs.length > 10) {
    res.status(400).json({ error: "max 10 jobs per batch" });
    return;
  }
  const results = await Promise.all(
    jobs.map((j) => executeCode(j.code, j.language, j.filename, j.stdin))
  );
  res.json({ results });
});

app.post("/api/lint", async (req, res) => {
  const { code, language } = req.body as { code: string; language: string };
  if (!code || !language) {
    res.status(400).json({ error: "code and language required" });
    return;
  }
  const lang = language.toLowerCase();
  let lintResult = { errors: [], warnings: [], info: [] as string[] };
  if (lang === "python" || lang === "py") {
    const r = await executeCode(`import py_compile, sys\ntry:\n  py_compile.compile('main.py', doraise=True)\n  print('OK')\nexcept py_compile.PyCompileError as e:\n  print(str(e), file=sys.stderr)`, "python");
    lintResult.info = [r.stdout.trim() || r.stderr.trim()];
  }
  res.json(lintResult);
});

app.post("/api/apk/info", upload.single("apk"), async (req, res) => {
  if (!req.file) {
    res.status(400).json({ error: "No APK file provided" });
    return;
  }
  res.json({
    name: req.file.originalname,
    size: req.file.size,
    sizeHuman: `${(req.file.size / 1024 / 1024).toFixed(2)} MB`,
    mimetype: req.file.mimetype,
    path: req.file.path,
    message: "APK received successfully.",
  });
});

app.get("/api/system", (_req, res) => {
  res.json({
    os: { platform: os.platform(), arch: os.arch(), release: os.release(), type: os.type() },
    cpu: { model: os.cpus()[0]?.model, count: os.cpus().length, speed: os.cpus()[0]?.speed },
    memory: {
      totalMB: Math.round(os.totalmem() / 1024 / 1024),
      freeMB: Math.round(os.freemem() / 1024 / 1024),
      usedMB: Math.round((os.totalmem() - os.freemem()) / 1024 / 1024),
    },
    node: process.version,
    pid: process.pid,
    uptime: Math.round(process.uptime()),
    env: process.env["NODE_ENV"] || "development",
  });
});

app.use((_req, res) => {
  res.status(404).json({ error: "Not found" });
});

const PORT = parseInt(process.env["PORT"] || "4000", 10);
server.listen(PORT, "0.0.0.0", () => {
  console.log(`SK Coder Backend v3.0.0`);
  console.log(`REST  : http://0.0.0.0:${PORT}/api/execute`);
  console.log(`WS    : ws://0.0.0.0:${PORT}/api/terminal`);
  console.log(`Health: http://0.0.0.0:${PORT}/health`);
  console.log(`Langs : ${SUPPORTED_LANGUAGES.length} languages supported`);
});
